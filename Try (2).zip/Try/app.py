from flask import Flask, render_template, Response
import cv2
import face_recognition
import os
import pickle
from datetime import datetime

app = Flask(__name__)
app.secret_key = "!@#$%"

def encode_faces(images_folder):
    known_faces = []
    known_names = []

    for filename in os.listdir(images_folder):
        if filename.endswith(".jpg") or filename.endswith(".png"):
            path = os.path.join(images_folder, filename)
            img = face_recognition.load_image_file(path)
            
            face_locations = face_recognition.face_locations(img)
            if not face_locations:
                print(f"No face found in {filename}")
                continue

            face_encoding = face_recognition.face_encodings(img, face_locations)[0]
            
            name = os.path.splitext(filename)[0]

            known_faces.append(face_encoding)
            known_names.append(name)

    with open("encodings.pkl", "wb") as f:
        pickle.dump((known_faces, known_names), f)

    return known_faces, known_names


def load_encodings():
    try:
        with open("encodings.pkl", "rb") as f:
            known_faces, known_names = pickle.load(f)
        return known_faces, known_names
    except FileNotFoundError:
        return [], []
def mark_attendance(known_faces, known_names):
    video_capture = cv2.VideoCapture(0)

    while True:
        ret, frame = video_capture.read()

        face_locations = face_recognition.face_locations(frame)
        face_encodings = face_recognition.face_encodings(frame, face_locations)

        for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
            matches = face_recognition.compare_faces(known_faces, face_encoding)
            name = "Unknown"

            if True in matches:
                first_match_index = matches.index(True)
                name = known_names[first_match_index]

            cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)
            cv2.putText(frame, name, (left + 6, bottom - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            if name != "Unknown":
                with open("attendance.txt", "a") as f:
                    f.write(f"{name} - {datetime.now()}\n")

        cv2.imshow('Video', frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    video_capture.release()
    cv2.destroyAllWindows()

def generate_frames():
    video_capture = cv2.VideoCapture(0)

    while True:
        success, frame = video_capture.read()
        if not success:
            break
        else:
            face_locations = face_recognition.face_locations(frame)
            face_encodings = face_recognition.face_encodings(frame, face_locations)

            for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
                matches = face_recognition.compare_faces(known_faces, face_encoding)
                name = "Unknown"

                if True in matches:
                    first_match_index = matches.index(True)
                    name = known_names[first_match_index]

                cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)
                cv2.putText(frame, name, (left + 6, bottom - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

                if name != "Unknown":
                    with open("attendance.txt", "a") as f:
                        f.write(f"{name} - {datetime.now()}\n")

            ret, jpeg = cv2.imencode('.jpg', frame)
            data = jpeg.tobytes()

            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + data + b'\r\n\r\n')

    video_capture.release()
    cv2.destroyAllWindows()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == "__main__":
    images_folder = "photos"
    known_faces, known_names = load_encodings()

    if not known_faces or not known_names:
        known_faces, known_names = encode_faces(images_folder)

    app.run(host="0.0.0.0", debug=True)
