import cv2
import face_recognition
import os
import pickle
from datetime import datetime

def encode_faces(images_folder):
    known_faces = []
    known_names = []

    for filename in os.listdir(images_folder):
        if filename.endswith(".jpg") or filename.endswith(".png"):
            path = os.path.join(images_folder, filename)
            img = face_recognition.load_image_file(path)

            # Check if faces are found in the image
            face_locations = face_recognition.face_locations(img)
            if not face_locations:
                print(f"No face found in {filename}")
                continue

            face_encoding = face_recognition.face_encodings(img, face_locations)[0]

            # Extract the name from the filename (assuming filenames are in the format "Name.jpg")
            name = os.path.splitext(filename)[0]

            known_faces.append(face_encoding)
            known_names.append(name)

    # Save the encodings to a file
    with open("encodings.pkl", "wb") as f:
        pickle.dump((known_faces, known_names), f)

    return known_faces, known_names


def load_encodings():
    try:
        with open("encodings.pkl", "rb") as f:
            known_faces, known_names = pickle.load(f)
        return known_faces, known_names
    except FileNotFoundError:
        return [], []


def mark_attendance(known_faces, known_names):
    video_capture = cv2.VideoCapture(0)

    while True:
        ret, frame = video_capture.read()

        face_locations = face_recognition.face_locations(frame)
        face_encodings = face_recognition.face_encodings(frame, face_locations)

        for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
            matches = face_recognition.compare_faces(known_faces, face_encoding, tolerance=0.6)
            name = "Unknown"

            if True in matches:
                first_match_index = matches.index(True)
                name = known_names[first_match_index]

            cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)
            cv2.putText(frame, name, (left + 6, bottom - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

            # Mark attendance (you can customize this part)
            if name != "Unknown":
                with open("attendance.txt", "a") as f:
                    f.write(f"{name} - {datetime.now()}\n")

        cv2.imshow('Video', frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    video_capture.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    images_folder = "photos"
    known_faces, known_names = load_encodings()

    if not known_faces or not known_names:
        known_faces, known_names = encode_faces(images_folder)

    mark_attendance(known_faces, known_names)
