from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from dbhelper import *
import base64

app = Flask(__name__)
app.secret_key = "!@#$%"
head = ['idno', 'lastname', 'firstname', 'course', 'level', 'action']

imagefolder = "static/img"
app.config["UPLOAD_FOLDER"] = imagefolder

    
@app.route("/register")
def register():
    return render_template("register.html", title="register")

@app.route("/send_email", methods=["POST"])
def send_email():
    email = request.form.get("email")
    password = request.form.get("password")
    image_data = request.form.get("image_data")

    # Construct the email message
    message = MIMEMultipart()
    message["Subject"] = "Face Registration Information"
    message["From"] = "your_email@example.com"
    message["To"] = email

    # Add the image data to the email message
    image = MIMEImage(base64.b64decode(image_data))
    image.add_header("Content-Disposition", "attachment; filename=image.jpg")
    message.attach(image)

    # Add the password to the email message
    message.attach(MIMEText(password, "plain"))

    # Send the email message
    smtp_server = smtplib.SMTP("smtp.example.com", 587)
    smtp_server.starttls()
    smtp_server.login("your_email@example.com", "your_password")
    smtp_server.sendmail("your_email@example.com", email, message.as_string())
    smtp_server.quit()

    return jsonify({"status": "success"})


@app.route('/saveimage', methods=['POST'])
def save_image():
    try:
        imagename = request.args.get('iname')
        imagepass = request.args.get('imagepass')

        # Get the raw data from the request
        raw_data = request.get_data(as_text=True)

        # Split the raw data to extract the base64-encoded data
        _, base64_data = raw_data.split(',', 1) if ',' in raw_data else ('', raw_data)

        # Decode the base64-encoded data
        decoded_image_data = base64.b64decode(base64_data)

        conn = sqlite3.connect('mystudentdb.db')
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS images (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                imagename TEXT,
                imagepass TEXT,
                image_data BLOB
            )
        ''')
        cursor.execute('INSERT INTO images (imagename, imagepass, image_data) VALUES (?, ?, ?)',
                       (imagename, imagepass, decoded_image_data))
        conn.commit()
        conn.close()

        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)})
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return response


@app.route("/logout")
def logout():
    if "username" in session:
        session.pop("username")
        flash("Logged Out")
    return render_template("index.html", title="my flask app")


@app.route("/savestudent", methods=['POST'])
def savestudent():
    flag = request.form['flag']
    print(flag)
    if "username" in session:
        idno = request.form['idno']
        lastname = request.form['lastname']
        firstname = request.form['firstname']
        course = request.form['course']
        level = request.form['level']
        if flag == "False":
            ok = addrecord('student', idno=idno, lastname=lastname, firstname=firstname, course=course, level=level)
            if ok:
                flash("New Student Added")
            return redirect("home")
        else:
            ok = updaterecord('student', idno=idno, lastname=lastname, firstname=firstname, course=course, level=level)
            if ok:
                flash("Student Updated")
            return redirect("home")
    else:
        flash("Login Properly")
        return redirect(url_for("login"))


@app.route("/deletestudent/<idno>")
def deletestudent(idno):
    if "username" in session:
        ok = deleterecord('student', idno=idno)
        if ok:
            flash("Student Deleted")
    return redirect(url_for("home"))


@app.route("/home")
def home():
    if "username" in session:
        slist = getall('student')
        return render_template("home.html", title="home", data=slist, header=head)
    else:
        flash("Login Properly")
        return render_template("index.html")


@app.route("/login", methods=['POST', 'GET'])
def login():
    if request.method == "POST":
        uname = request.form['username']
        pword = request.form['password']
        # set a static user validation
        user = userlogin('user', username=uname, password=pword)
        print(dict(user[0]))
        if len(user) > 0:
            session['username'] = uname
            return redirect(url_for("home"))
        else:
            flash("Invalid User")
            return render_template("login.html", title="student v1.0")
    else:
        return render_template("login.html", title="student v1.0")


@app.route("/")
def main():
    return render_template("index.html", title="my flask app")


if __name__ == "__main__":
    app.run(host="0.0.0.0", debug=True)
